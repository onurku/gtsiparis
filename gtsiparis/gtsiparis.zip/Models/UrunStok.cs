﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace gtsiparis.Models
{
    public class Uruntok
    {
        public Urun Urun { get; set; }
        public Stok Stok { get; set; }

    }
}