﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using gtsiparis.Models;

namespace gtsiparis.Models
{
    public class MenuViewModels
    {
        public IEnumerable<Menu> MenuItems { get; set; }

    }
}