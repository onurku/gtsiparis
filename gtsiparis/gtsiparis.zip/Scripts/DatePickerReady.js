﻿$(function () { // will trigger when the document is ready
    $('.datepicker').datepicker(
        { dateFormat: 'dd.mm.yyyy' }
    ); //Initialise any date pickers
});